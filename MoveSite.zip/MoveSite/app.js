// Листание списка
{

    const arrows = document.querySelectorAll(".arrow"); // Объекты для листания списка по горизонтали
    const movieLists = document.querySelectorAll(".movie-list"); // Список списков с тайтлами

    arrows.forEach((arrow, i) => {
        const itemNumber = movieLists[i].querySelectorAll("img").length; // Порядковый номер картинки в списке

        let clickCounter = 0;
        arrow.addEventListener("click", () => {
            const ratio = Math.floor(window.innerWidth / 270);
            clickCounter++;
            if (itemNumber - (4 + clickCounter) + (4 - ratio) > 0) {
                movieLists[i].style.transform = `translateX(${movieLists[i].computedStyleMap().get("transform")[0].x.value - 300}px)`;
            }
            else {
                movieLists[i].style.transform = "translateX(0)";
                clickCounter = 0;
            }
        });
    });

}

// Изменение темы
{

    const ball = document.querySelector(".toggle-ball"); // Объект для смены темы
    // Свойства описанные в css, что будут изменены после смены темы
    const items = document.querySelectorAll(".container, .movie-list-title, .navbar-container, .sidebar, .left-menu-icon, .toggle, .toggle-ball, .menu-gyp");

    ball.addEventListener("click", () => {
        items.forEach(item => {
            item.classList.toggle("active");
        });
        ball.classList.toggle("active");
    });

}

// Открытие страницы тайтла
{
    
}